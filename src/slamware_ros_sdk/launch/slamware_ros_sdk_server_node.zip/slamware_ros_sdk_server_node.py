<launch>
  <arg name="ip_address" default="192.168.11.1" />
  <arg name="raw_ladar_data" default="false" />

  <node pkg="slamware_ros_sdk" exec="slamware_ros_sdk_server_node" name="slamware_ros_sdk_server_node" output="both">

  <param name="ip_address"               value="$(var ip_address)"/>
  <param name="angle_compensate"         value="true"/>
  <param name="raw_ladar_data"           value="$(var raw_ladar_data)"/>

  <param name="map_frame"                value="slamware_map"/>
  <param name="robot_frame"              value="base_link"/>
  <param name="odom_frame"               value="odom"/>
  <param name="laser_frame"              value="laser"/>
  <param name="imu_frame"                value ="imu_link"/>
  <param name="camera_left"              value ="camera_left"/>
  <param name="camera_right"             value ="camera_right"/>

  <param name="robot_pose_pub_period"    value="0.05"/>
  <param name="scan_pub_period"          value="0.1"/>
  <param name="map_pub_period"           value="0.2"/>
  <param name="imu_raw_data_period"      value="0.005"/>

  <param name= "ladar_data_clockwise"    value= "true"/>
  <param name = "robot_pose_topic"            value = "robot_pose"/>
  
  <!-- topic remap /-->
  <remap from="scan"                       to="scan"/>
  <remap from="odom"                       to="odom"/>
  <remap from="map"                        to="slamware_map"/>
  <remap from="map_metadata"               to="map_metadata"/>
  </node>

  <node pkg="tf2_ros" exec="static_transform_publisher" name="odom2map" 
      args="--x 0 --y 0 --z 0 --qx 0 --qy 0 --qz 0 --qw 1 --frame-id slamware_map --child-frame-id odom"/>
  <node pkg="tf2_ros" exec="static_transform_publisher" name="laser2base" 
      args="--x 0 --y 0 --z 0.0315 --qx 0 --qy 0 --qz 0 --qw 1 --frame-id base_link --child-frame-id laser"/>
  <node pkg="tf2_ros" exec="static_transform_publisher" name="leftcam2base" 
      args="--x 0.0418 --y 0.03 --z 0 --qx -0.5 --qy 0.5 --qz -0.5 --qw 0.5 --frame-id base_link --child-frame-id camera_left"/>
  <node pkg="tf2_ros" exec="static_transform_publisher" name="rightcam2Leftcam" 
      args="--x 0.06 --y 0 --z 0 --qx 0 --qy 0 --qz 0 --qw 1 --frame-id camera_left --child-frame-id camera_right"/>
  <node pkg="tf2_ros" exec="static_transform_publisher" name="imu2Leftcam" 
      args="--x 0.03 --y 0 --z 0 --qx 0 --qy 0 --qz -0.7071068 --qw 0.7071068 --frame-id camera_left --child-frame-id imu_link"/>
</launch>
